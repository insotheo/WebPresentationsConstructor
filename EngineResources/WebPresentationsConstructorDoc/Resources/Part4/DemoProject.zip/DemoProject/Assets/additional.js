//_EDITOR::FUNCTIONS::TYPES::EVENT
function backColorChange(input_name){
    let body = document.getElementsByTagName("body")[0];
    let inp = document.getElementById(input_name);
    body.style.background = inp.value
}

//_EDITOR::FUNCTIONS::TYPES::EVENT
function countAndSet(input_name, text_name, list_name){
    const historyNote = document.getElementById(input_name).value + " = " + eval(document.getElementById(input_name).value).toString();
    const result = "Ответ: " + eval(document.getElementById(input_name).value).toString();
    let list = document.getElementById(list_name);
    let li = document.createElement("li");
    li.appendChild(document.createTextNode(historyNote));
    list.appendChild(li);
    document.getElementById(text_name).textContent = result;
}